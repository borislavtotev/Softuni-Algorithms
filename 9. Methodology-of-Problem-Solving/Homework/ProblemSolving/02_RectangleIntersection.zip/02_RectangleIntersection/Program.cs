﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wintellect.PowerCollections;

namespace _02_RectangleIntersection
{
    class Program
    {
        static OrderedSet<Rectangle> rectangles;
        static decimal commonArea;
        static OrderedSet<int> x;
        static OrderedSet<int> y;
        static MultiDictionary<Tuple<int, int>, Rectangle> rectanglesByXIntervals;
        static MultiDictionary<Tuple<int, int>, Rectangle> rectanglesByYIntervals;

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            rectangles = new OrderedSet<Rectangle>();
            x = new OrderedSet<int>();
            y = new OrderedSet<int>();
            rectanglesByXIntervals = new MultiDictionary<Tuple<int, int>, Rectangle>(true);

            for (int i = 0; i < n; i++)
            {
                var coordinates = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
                x.Add(coordinates[0]);
                x.Add(coordinates[1]);
                y.Add(coordinates[2]);
                y.Add(coordinates[3]);

                rectangles.Add(new Rectangle(coordinates[0], coordinates[1], coordinates[2], coordinates[3]));
            }          

            foreach (var rectangle in rectangles)
            {
                var xElements = x.Range(rectangle.MinX, true, rectangle.MaxX, true).ToArray();
                var xElementsCount = xElements.Count();
                for (int i = 0; i < xElementsCount - 1; i+=1)
                {
                    Tuple<int, int> tuple = new Tuple<int, int>(xElements[i], xElements[i + 1]);
                    rectanglesByXIntervals.Add(tuple, rectangle);
                }
            }

            foreach (var xInterval in rectanglesByXIntervals.Keys)
            {
                rectanglesByYIntervals = new MultiDictionary<Tuple<int, int>, Rectangle>(true);
                var rectanglesByX = rectanglesByXIntervals[xInterval];
                var minYs = rectanglesByX.Select(r => r.MinY).ToList();
                var maxYs = rectanglesByX.Select(r => r.MaxY).ToList();
                OrderedSet<int> allYs = new OrderedSet<int>();
                minYs.ForEach(y => allYs.Add(y));
                maxYs.ForEach(y => allYs.Add(y));
                foreach (var rectangle in rectanglesByX)
                {
                    var yElements = y.Range(rectangle.MinY, true, rectangle.MaxY, true);
                    var yElementsCount = yElements.Count();
                    for (int i = 0; i < yElementsCount - 1; i += 1)
                    {
                        Tuple<int, int> tuple = new Tuple<int, int>(yElements[i], yElements[i + 1]);
                        rectanglesByYIntervals.Add(tuple, rectangle);
                    }
                }

                var keys = rectanglesByYIntervals.Keys.ToList();

                foreach (var intervalY in keys)
                {
                    var commonRectanglesCount = rectanglesByYIntervals[intervalY].Count;
                    rectanglesByYIntervals.Remove(intervalY);
                    if (commonRectanglesCount >= 2)
                    {
                        var currentRectangle = new Rectangle(xInterval.Item1, xInterval.Item2, intervalY.Item1, intervalY.Item2);
                        var currentArea = currentRectangle.CalculatedArea();
                        commonArea += currentArea;
                    }
                }
            }

            Console.WriteLine(commonArea);
        }
    }

    class Rectangle: IComparable<Rectangle>
    {
        public Rectangle(int minX, int maxX, int minY, int maxY)
        {
            this.MinX = minX;
            this.MaxX = maxX;
            this.MinY = minY;
            this.MaxY = maxY;
        }

        public int MinX { get; set; }

        public int MaxX { get; set; }

        public int MinY { get; set; }

        public int MaxY { get; set; }

        public int CompareTo(Rectangle other)
        {
            return this.MinX.CompareTo(other.MinX);
        }

        public decimal CalculatedArea()
        {
            return Math.Abs((this.MaxX - this.MinX) * (this.MaxY - this.MinY));
        }
    }
}
